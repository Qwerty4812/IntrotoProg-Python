#########################################################
#
#   Assignment 05 - Working with Lists and Dictionaries
#
#   Dan Li, last modified: 11/13/2018

# Variable Initialization
dictionary = {}

# Loading ToDo.txt file into Python dictionary d
with open('ToDo.txt', 'r') as f:
    for row in f:
        task, priority = row.strip().split(',', 1)
        dictionary[task] = priority

# Display a menu of choices to the user
while(True):
    print("""Menu of options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program""")

    strUserInput = input('Input Command ')

    # Different program paths depending on user input
    if int(strUserInput.strip()) == 1:              # List out the dictionary values
        for row in dictionary:
            print(row, ':', dictionary[row])

    if int(strUserInput.strip()) == 2:              # Add another value to the dictionary
        print("Separate inputs by comma")
        newtask, priority = input('Input new task and priority = ').split(',', 1)

        dictionary[newtask] = priority

    if int(strUserInput.strip()) == 3:              # Delete value from dictionary
        print(list(dictionary))
        delete_task = input("Type out which entry you wish to delete ")
        del dictionary[delete_task]

    if int(strUserInput.strip()) == 4:              # Save dictionary to .txt file
        with open("todo.txt", 'w+') as f:
            f.write('\n'.join('{}, {}'.format(row, dictionary[row]) for row in dictionary))

        print('\n', 'File Saved')

    if int(strUserInput.strip()) == 5:              # Exit the program
        break


