# Dan Li Pickling

import pickle

a = ['test value', 'test value 2', 'test value 3']

with open('filename.txt', 'wb') as f:
    # this writes the object a to the
    # file named 'testfile'
    pickle.dump(a, f)

# write this data to a pickle file to store the data for later use
# Can recall the data later so my program can return to the original state (start from where it left off)

with open('filename.txt', 'rb') as f:
    # this writes the object a to the
    # file named 'testfile'
    b = pickle.load(f)

print(b)