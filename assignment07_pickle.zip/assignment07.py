# Dan Li Exception Handling

while True:
    try:
        num = int(input("input a number please: "))
        x = num + 5

        break

    except ValueError:
        print("That's not a number!")
